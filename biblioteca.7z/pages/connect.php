<?php

      function encontrouNumeros($string) {
            return (filter_var($string, FILTER_SANITIZE_NUMBER_INT) === '' ? false : true);
      }

      #PEGAR CAMPOS
      $nome = strtoupper($_POST["nameCliente"]);
      $cpf = $_POST["cpfCliente"];
      $rg = $_POST["rgCliente"];
      $data_nascimento = $_POST["nascimentoCliente"];
      $telefone = $_POST["telefoneCliente"];
      $cidade = strtoupper($_POST["cidadeCliente"]);
      $bairro = strtoupper($_POST["bairroCliente"]);
      $rua = strtoupper($_POST["ruaCliente"]);
      $n_complemento = strtoupper($_POST["numComplementoCliente"]);
      
      $connect = mysqli_connect("localhost", "root", "", "database");
      
      mysqli_query(
            $connect, 
            "INSERT INTO cliente values ('$nome', $cpf, $rg, '$data_nascimento', '$telefone', '$cidade', '$bairro', '$rua', '$n_complemento');"
      );
      
      header("location:consulta_cliente_2.php");
      
?>
